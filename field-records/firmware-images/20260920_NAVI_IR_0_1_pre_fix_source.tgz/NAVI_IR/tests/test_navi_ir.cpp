#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <set>
#include <string>
#include "MovementEvidence.h"
#include "Navigator.h"
#define NAVI_APPROACH_MARKER_MS {1390,1539,1725,1960,2271}
#include "RecoveryControl.h"
#include "HallObserver.h"
using namespace ngr_nav;
using namespace navi_one;

static const uint8_t MAC[6]={2,3,4,5,6,7};
static WireSnapshot packet(uint32_t seq,uint64_t pulses,uint64_t us,uint64_t boot=1){
  WireSnapshot w;w.sequence=seq;w.bootId=boot;w.capturedUs=us;
  w.observedRises=w.completedPulses=pulses;w.nominalUm=pulses*w.pitchUm;
  w.opticalReason=ir_movement::TRACKING;
  w.crc=movementCrc(reinterpret_cast<uint8_t*>(&w),108);return w;
}
static RxResult send(MovementSource& s,WireSnapshot w,uint64_t at,const uint8_t* mac=MAC){
  return s.receive(mac,reinterpret_cast<uint8_t*>(&w),sizeof(w),at);
}
static MotionPoint point(uint64_t n,uint32_t ms){
  MotionPoint p;p.wire=packet(ms,n,uint64_t(ms)*1000);p.arrivalUs=uint64_t(ms)*1000;
  p.frame=1;p.issue=MotionIssue::None;return p;
}
static NavObservation event(uint8_t marker,uint32_t ms,double travel){
  NavObservation e;e.openedAtMs=ms;e.polarity=e.windowPolarity=polarityAt(marker);
  e.windowValid=true;e.movement=point(std::llround(travel/9.652),ms);return e;
}

int main(){
  unsigned checks=0;
  MovementSource s;
  assert(send(s,packet(1,10,1000000),2000000)==RxResult::Unpaired);++checks;
  s.pair(MAC);
  assert(send(s,packet(1,10,1000000),2000000)==RxResult::Accepted);
  auto a=s.at(2000000,2000000);
  assert(a.issue==MotionIssue::None && a.alignmentUs==0);++checks;
  assert(send(s,packet(1,10,1000000),2500000)==RxResult::Duplicate);
  assert(s.lastArrival()==2000000);++checks;
  assert(send(s,packet(4,19,1300000),2300000)==RxResult::Accepted);
  auto b=s.at(2300000,2300000);
  assert(ngr_nav::between(a,b).pulses==9 && ngr_nav::between(a,b).usable());++checks;
  assert(s.at(2300000,3400001).issue==MotionIssue::Stale);++checks;
  assert(s.at(500000,2300000).issue==MotionIssue::Unaligned);++checks;
  auto bad=packet(5,20,1400000);bad.crc^=1;
  assert(send(s,bad,2400000)==RxResult::Invalid);++checks;
  uint8_t foreign[6]={2,8,8,8,8,8};
  assert(send(s,packet(5,20,1400000),2400000,foreign)==RxResult::WrongSource);++checks;
  assert(send(s,packet(3,18,1200000),2400000)==RxResult::Old);++checks;
  auto quality=b;quality.wire.unreliableSamples++;
  assert(ngr_nav::between(a,quality).issue==MotionIssue::Interrupted);++checks;
  quality=b;quality.wire.opticalReason=ir_movement::INADEQUATE_CONTRAST;
  assert(ngr_nav::between(a,quality).issue==MotionIssue::Optical);++checks;
  s.newFrame();assert(send(s,packet(5,20,1400000),2400000)==RxResult::Accepted);
  assert(ngr_nav::between(b,s.at(2400000,2400000)).issue==MotionIssue::Direction);++checks;
  assert(send(s,packet(1,0,10000,2),2500000)==RxResult::Reset);
  assert(send(s,packet(6,21,1500000,1),2600000)==RxResult::Old);++checks;
  assert(!ngr_nav::between(a,b).bounded());++checks;
  auto huge=packet(2,1,UINT64_MAX,2);
  assert(send(s,huge,2700000)==RxResult::Invalid);++checks;
  assert(s.at(UINT64_MAX,2700000).issue==MotionIssue::NoSource);++checks;
  s.transportGap();assert(s.at(2500000,2700000).issue==MotionIssue::NoSource);++checks;
  s.pair(MAC);
  for(uint64_t boot=10;boot<=18;++boot) {
    const auto rx=send(s,packet(1,0,10000,boot),boot*1000000);
    assert(rx==(boot==10?RxResult::Accepted:RxResult::Reset));
  }
  assert(send(s,packet(1,0,10000,19),19000000)==RxResult::Exhausted);++checks;

  Navigator n;n.declare(170,1);
  assert(n.judge(event(0,1000,0))==Ruling::Ambiguous); // first Hall establishes wheel anchor
  assert(n.judge(event(1,2000,330))==Ruling::Reestablished);
  assert(n.status().navMm==1 && n.status().distanceConfirmed);++checks;
  auto unknown=event(2,3000,670);unknown.movement.issue=MotionIssue::Stale;
  assert(n.judge(unknown)==Ruling::Ambiguous && !n.positionKnown());++checks;

  // Same-polarity false event: distance creates ambiguity BEFORE polarity can.
  n.declare(170,1);n.judge(event(0,1000,0));
  assert(n.judge(event(1,2000,70))==Ruling::Ambiguous);
  assert(n.hypotheses().count()>=2);++checks;
  double mm=0;uint32_t now=3000;bool recovered=false;
  for(uint8_t marker=1;marker<=14;++marker,now+=1000){
    mm+=spanMm(marker-1,1);auto ruling=n.judge(event(marker,now,mm));
    if(ruling==Ruling::Reestablished)recovered=true;
    assert(n.status().state!=NavState::LimitStopped);
  }
  assert(recovered && n.positionKnown() && n.status().navMm==14);
  for(uint8_t i=0;i<n.hypotheses().count();++i)assert(n.hypotheses().hypothesis(i).faults==0);++checks;
  // A second separated anomaly is eligible for recovery, not lifetime strike two.
  assert(n.judge(event(15,now,mm+60))==Ruling::Ambiguous);++checks;

  // Missing a same-polarity marker is visible in distance, not just the word.
  n.declare(1,1);n.judge(event(2,1000,0));
  n.judge(event(4,3000,spanMm(2,1)+spanMm(3,1)));
  bool has4=false;for(uint8_t i=0;i<n.hypotheses().count();++i)if(n.hypotheses().hypothesis(i).mm==4)has4=true;
  assert(has4 && n.unresolved());++checks;

  navi_hypothesis::HypothesisNavigator hypotheses;
  navi_hypothesis::Observation disagree;disagree.atMs=1000;disagree.openingPolarity=0;
  disagree.windowPolarity=1;disagree.windowValid=true;
  hypotheses.declare(30,1,0);hypotheses.observe(disagree);
  StationMachine station;
  assert(stationConsensus(station,hypotheses,90,90,1000).agrees);++checks;
  hypotheses.declare(3,1,0);hypotheses.observe(disagree);
  assert(!stationConsensus(station,hypotheses,90,90,1000).agrees);++checks;
  n.declare(40,1);n.setDirection(-1);assert(!n.positionKnown());++checks;

  // Clean full laps in both directions, including wraparound.
  for(int8_t dir:{int8_t(1),int8_t(-1)}){
    uint8_t marker=dir>0?170:0;n.declare(marker,dir);
    double travel=0;uint32_t time=1000;
    for(unsigned i=0;i<ROUTE_N*2;++i,time+=1000){
      travel+=spanMm(marker,dir);marker=nextMarker(marker,dir);
      n.judge(event(marker,time,travel));
      assert(i==0?n.unresolved():n.positionKnown());
      if(i)assert(n.status().navMm==marker);
    }
    n.setDirection(-dir);assert(!n.status().distanceConfirmed);++checks;
  }
  // The ten-observation renewal word is actually unique on the current map.
  for(int8_t dir:{int8_t(1),int8_t(-1)}){
    std::set<std::string> words;
    for(unsigned start=0;start<ROUTE_N;++start){
      std::string word;uint8_t marker=start;
      for(unsigned i=0;i<10;++i){word+=char('0'+polarityAt(marker));marker=nextMarker(marker,dir);}
      assert(words.insert(word).second);
    }
    ++checks;
  }
  n.declare(170,1);
  for(uint8_t i=0;i<=10;++i){
    auto e=event(i,1000+1000*i,0);e.movement.issue=MotionIssue::Stale;n.judge(e);
  }
  assert(n.status().state==NavState::LimitStopped && !n.status().distanceConfirmed);++checks;

  // Exactly half a mapped span is not a distance confirmation.
  n.declare(170,1);
  auto e=event(0,1000,0);e.movement.wire.pitchUm=1000;n.judge(e);
  e=event(1,2000,0);e.movement.wire.pitchUm=1000;
  e.movement.wire.completedPulses=spanMm(0,1)/2;
  assert(n.judge(e)==Ruling::Ambiguous && !n.status().distanceConfirmed);++checks;

  // A timeout in an armed station must never hand cruise power back.
  station.tick(5,1,90,90,1000);
  hypotheses.declare(5,1,1000);
  assert(!stationConsensus(station,hypotheses,60,90,1000+STATION_MAX_PHASE_MS+1).agrees);++checks;

  // No inherited PWM-as-distance re-prime or refractory exclusion in the adapter.
  const auto config=hallConfig(38);
  assert(config.lostMs==0 && config.refractoryMs==0);++checks;
  std::cout<<"PASS "<<checks<<" NAVI_IR transport, joint-evidence, recovery and control checks\n";
}
