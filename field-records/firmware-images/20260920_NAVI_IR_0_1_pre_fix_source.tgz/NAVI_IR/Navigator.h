#pragma once
#include "HypothesisNavigator.h"

namespace navi_one {
struct NavObservation {
  uint32_t openedAtMs=0;
  uint8_t polarity=0,windowPolarity=0;
  bool directionConflict=false,restartUncertain=false,windowValid=false;
  ngr_nav::MotionPoint movement{};
};
enum class NavState : uint8_t { Unset, Declared, Unresolved, LimitStopped };
inline const char* navStateName(NavState s){switch(s){case NavState::Declared:return "TRACKING";case NavState::Unresolved:return "AMBIGUOUS";case NavState::LimitStopped:return "LOST";default:return "UNSET";}}
enum class Ruling : uint8_t { Advanced, NoPosition, Ambiguous, Reestablished, UnresolvedLimitStop, Retained };
inline const char* rulingName(Ruling s){switch(s){case Ruling::Advanced:return "ADVANCED";case Ruling::Ambiguous:return "AMBIGUOUS";case Ruling::Reestablished:return "REESTABLISHED";case Ruling::UnresolvedLimitStop:return "RECOVERY_EXHAUSTED";case Ruling::Retained:return "FALSE_OBSERVATION";default:return "NO_POSITION";}}
enum class Trust : uint8_t { Declared, Sequence };
inline const char* trustName(Trust t){return t==Trust::Sequence?"CONDITIONAL_SEQUENCE":"DECLARED";}
struct NavStatus {
  NavState state=NavState::Unset;
  uint8_t navMm=0,target=0;
  int8_t navDir=0;
  Trust trust=Trust::Declared;
  uint32_t advances=0,refusals=0;
  uint8_t unresolvedCount=0,sequenceLength=0;
  uint16_t sequenceMatches=0;
  bool distanceConfirmed=false;
};
class Navigator {
 public:
  const NavStatus& status() const{return s_;}
  const navi_hypothesis::HypothesisNavigator& hypotheses() const{return core_;}
  bool positionKnown() const{return s_.state==NavState::Declared;}
  bool unresolved() const{return s_.state==NavState::Unresolved;}
  bool takeResetRequest(){bool r=reset_;reset_=false;return r;}
  void haltForLoss(){s_.state=NavState::LimitStopped;s_.distanceConfirmed=false;}
  void declare(uint8_t mm,int8_t dir){s_=NavStatus{};s_.navMm=mm;s_.navDir=dir;s_.target=nextMarker(mm,dir);core_.declare(mm,dir,0);s_.state=dir?NavState::Declared:NavState::Unset;reset_=true;}
  // Unsigned wheel movement cannot establish a reversed route frame.
  void setDirection(int8_t dir){if(dir!=s_.navDir){s_.navDir=dir;s_.state=NavState::Unset;s_.distanceConfirmed=false;reset_=true;}}
  Ruling judge(const NavObservation& p){
    if(s_.state==NavState::Unset || s_.state==NavState::LimitStopped)return Ruling::NoPosition;
    if(p.directionConflict){s_.state=NavState::Unset;s_.distanceConfirmed=false;return Ruling::NoPosition;}
    const bool wasAmbiguous=unresolved();
    navi_hypothesis::Observation o;
    o.atMs=p.openedAtMs;o.openingPolarity=p.polarity;o.windowPolarity=p.windowPolarity;
    o.windowValid=p.windowValid;o.movement=p.movement;
    const auto result=core_.observe(o);
    s_.sequenceMatches=core_.count();
    s_.distanceConfirmed=core_.count()>0;
    for(uint8_t i=0;i<core_.count();++i)
      if(!core_.hypothesis(i).distanceAgrees)s_.distanceConfirmed=false;
    if(result==navi_hypothesis::Result::Lost){haltForLoss();return Ruling::UnresolvedLimitStop;}
    if(result==navi_hypothesis::Result::Ambiguous || !s_.distanceConfirmed){
      s_.state=NavState::Unresolved;++s_.refusals;
      s_.unresolvedCount=wasAmbiguous?s_.unresolvedCount+1:0;
      if(s_.unresolvedCount>=10){haltForLoss();return Ruling::UnresolvedLimitStop;}
      return Ruling::Ambiguous;
    }
    const uint8_t mm=core_.position();const bool advanced=mm!=s_.navMm;
    s_.navMm=mm;s_.target=nextMarker(mm,s_.navDir);s_.state=NavState::Declared;s_.unresolvedCount=0;
    s_.sequenceLength=core_.hypothesis(0).clean;
    if(s_.sequenceLength>=10)s_.trust=Trust::Sequence;
    if(advanced)++s_.advances;
    return wasAmbiguous?Ruling::Reestablished:advanced?Ruling::Advanced:Ruling::Retained;
  }
 private:
  navi_hypothesis::HypothesisNavigator core_;
  NavStatus s_{};bool reset_=false;
};
}
