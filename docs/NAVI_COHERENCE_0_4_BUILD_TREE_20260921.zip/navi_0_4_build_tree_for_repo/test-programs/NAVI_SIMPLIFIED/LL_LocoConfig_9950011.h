#pragma once
// ============================================================================
// LL_LocoConfig_9950011.h
// Profile: Otto (9950011)
// ============================================================================

#include "../../QUORUM/credentials.h"   // existing private locomotive credentials

// Identity
#define LOCO_NAME "9950011"
#define LOCO_ID 9950011UL
#define NAVI_MAX_OPERATING_PWM 120
#define NAVI_PHYSICAL_VMAX_MM_S 1000UL
#define HALL_POLARITY_INVERTED true

// ---------------------------------------------------------------------------
// IR Test A (docs/QUORUM_1_16R_IR_TEST_A_FIRMWARE_SPEC.md §2). Otto carries the
// sensor car as of 2026-08-18, taking it over from Toby: the phantom markers
// this layer exists to discriminate are Otto's. His 2026-08-17 night session
// logged 21 LOW_PWM-gated acceptances, ~half carrying the same weak signature
// (peak 38-49) that gets QUARANTINED at working PWM — accepted unvalidated only
// because navLadder's velocity model switches off below GATE_LOW_PWM_FLOOR.
// IR measures speed in exactly that regime.
//
// The sender registers ONE peer, so this is a hand-off, not an addition: while
// Otto is paired, Toby's profile must keep IR_TEST_A_ENABLED absent.
//
// The MAC is the Test Car ESP32's STA MAC — fill in at bench pairing (spec
// §11.3 step 1; the sender prints it at boot). ALL-ZERO IS A SAFE PLACEHOLDER:
// reception stays disabled and is reported; it never falls back to accepting
// any sender.
// ---------------------------------------------------------------------------
// #ifndef-guarded so an EARLIER definition wins. tests/harness.cpp defines both
// of these before including QUORUM.ino, so that the receiver paths are testable
// "regardless of the compiled profile" (harness.cpp:52). That was only ever true
// while Otto's profile had no IR block: an unconditional #define here is seen
// AFTER the harness's, silently overrides it, and every fixture packet is then
// rejected as bad-source — 17 IR tests fail with state NO_SENSOR and no hint of
// why. Nothing in a real build defines these first, so the guard changes no
// flashed behaviour.
#ifndef IR_TEST_A_ENABLED
#define IR_TEST_A_ENABLED 1
#endif
#ifndef IR_SENSOR_MAC_BYTES
#define IR_SENSOR_MAC_BYTES {0xEC,0xE3,0x34,0x78,0xA2,0x60}   // IR Test Car, bench-paired 2026-08-18
#endif

// Blynk
#define BLYNK_TEMPLATE_ID "TMPL2xjo1-Ltx"
#define BLYNK_TEMPLATE_NAME "Loco Driver I"
#define BLYNK_AUTH_TOKEN BLYNK_AUTH_TOKEN_9950011

// Blynk virtual pins
#define VPIN_THROTTLE V1
#define VPIN_DIRECTION V0
#define VPIN_BRAKE V3
#define VPIN_ESTOP V2
#define VPIN_LOWVOLT_LED V4
#define VPIN_VOLTAGE_DISPLAY V5
#define VPIN_CURRENT_DISPLAY V6

// Motor control pins
//
// MOTOR_DIR_PIN is 16, NOT 2. Otto's ESP32 was replaced; the new board wires
// direction to GPIO 16. Commit 4f6e0b0 (2026-09-09) made that change in the
// QUORUM profiles he was actually flashing and nowhere else, so every NAVI
// profile carried 2 until now. Flashing Otto with 2 drives the direction line
// into a pin that is not connected to the H-bridge: the locomotive would
// answer the throttle and ignore the map's sense of forward.
//
// Toby's board is unchanged and stays on 2. This is a per-board fact, not a
// fleet constant.
#define MOTOR_PWM_PIN 4
#define MOTOR_DIR_PIN 16

#define PWM_CHANNEL 0
#define PWM_FREQUENCY 20000
#define PWM_RESOLUTION 8

// CTO3 consist extent — decision 0030/0033, spec docs/CTO3/BUBBLE_V1_SPEC.md.
// Occupied track relative to the Hall sensor, in MARKERS (mile markers, the
// control frame — never millimetres). A property of the CONSIST: change these
// when cars are added or removed. The producer applies them to its own
// published bounds; consumers receive occupied track, not a sensor point.
#define CONSIST_EXTENT_FRONT_MARKERS 2
#define CONSIST_EXTENT_REAR_MARKERS  4

// Direction values
#define DIRECTION_REVERSE 0
#define DIRECTION_NEUTRAL 1
#define DIRECTION_FORWARD 2
#define SAFE_DIRECTION_CHANGE_PWM 15

// Speed constants
#define NORMAL_PWM 110

// Ramp behavior
#define RAMP_UP_DELAY_MS   150UL
#define RAMP_DOWN_DELAY_MS 100UL

// Voltage thresholds
#define DISCONNECTED_VOLTAGE_THRESHOLD 12.5f
#define THROTTLE_LIMIT_VOLTAGE 13.5f
#define SHUTDOWN_VOLTAGE 13.25f
#define RECOVERY_VOLTAGE 14.0f
#define MIN_THROTTLE_PWM 60
#define VOLTAGE_COUNTER_LIMIT 5
#define VOLTAGE_REPORT_INTERVAL_MS 120000UL
#define VOLTAGE_DISPLAY_INTERVAL_MS 60000UL

// ---------------------------------------------------------------------------
// Hall thresholds. Previously undefined, so Otto ran on the sketch fallbacks
// of 50/80/80 — an entry threshold of 130 counts.
//
// Measured 2026-07-28, five CW laps, 769 markers: peak minimum was exactly
// 130 and the fifth percentile 137. The distribution was truncated at the
// threshold, which is what a threshold cutting into the signal looks like.
// 4% of markers were being missed and nothing showed it.
//
// These are Toby's values, which run at 0.5% error with zero spurious events.
// Entry drops from 130 to 38 — well below the observed floor, well above the
// few counts of baseline noise.
// ---------------------------------------------------------------------------
#define HALL_DEADBAND_COUNTS       25
// ---------------------------------------------------------------------------
// 2026-08-20, PHANTOM GATE. The operator realigned Otto's Hall sensor this
// afternoon and his mean peak rose 146.7 -> 176.4 (Toby sits at ~193). That fix
// exposed the real defect: with genuine markers now reading 104-295, a
// population of SPURIOUS events at peak 40-91 and duration 40-58 ms became
// unmistakable. They were always there; before the realignment they overlapped
// the genuine distribution and could not be separated.
//
// Measured, 596 markers after the realignment:
//     genuine reads   585, peak 104 minimum, duration 116 ms minimum
//     spurious reads   11, peak  91 maximum, duration  40-58 ms (9 of them)
// A clean gap from 91 to 104, with nothing in between.
//
// These phantoms cost a NO_QUORUM at 14:30:51. Reads of peak 40, 51, 49 and 43
// at mm 16, 19, 20, 21 were admitted as markers, advancing navMm ahead of the
// physical locomotive; the polarity sequence desynchronised, the quorum opened
// and never resolved.
//
// The entry threshold is baseline +/- (DEADBAND + ENTRY_MARGIN) = 25 + 13 = 38
// counts, and EVENT_FLOOR_MS is 40 ms. The phantoms cleared BOTH by a hair.
// Raising the entry margin to 65 puts entry at 90 counts: above every observed
// phantom, and 14 counts below the weakest genuine read.
//
// NOTE for whoever reads this next: HALL_MIN_PEAK_DELTA below gates NOTHING.
// It appears only in the boot telemetry string. So does HALL_DOMINANCE_PERCENT
// in Toby's profile. Changing either has no effect on detection; the entry
// threshold is the only amplitude gate there is.
//
// RISK, stated plainly: a genuine marker whose peak falls below 90 counts is
// now MISSED, and a missed marker drifts position - the failure that bit Otto
// in July when he ran on the 50/80/80 fallbacks. The 14-count margin rests on
// ONE session at one temperature (92 F). If Otto starts missing markers, this
// is the first thing to revisit.
// ---------------------------------------------------------------------------
//
// 2026-08-20, SAME EVENING — 65 was too aggressive and is reduced to 45
// (entry 70). The 90-count gate ran eight minutes with 208 markers and ZERO
// disagreements, the cleanest stretch Otto produced all day, and then his
// position fell FOUR markers behind the railway around mm 100-125: quorum
// adopted offset +4 at 16:11:12 and gave up at mm 123. The gate was rejecting
// genuine markers in a stretch that runs weaker than the 596-marker sample
// used to set it (whose minimum was 104).
//
// 70 keeps the phantom cluster out (peaks 40-66) and restores 34 counts of
// headroom under the weakest genuine read measured.
//
// AND A CORRECTION TO THE WATCH SIGNAL RECORDED IN 0040: steps of 2 in the
// marker sequence do NOT reveal missed markers. A rejected event never reaches
// telemetry, so the next accepted marker still reads mm+1 and the step stays
// 1 while the position silently lags. 241 of 247 steps were 1 while four
// markers went missing. The real signature is the quorum adopting POSITIVE
// offsets, and dt_conserve_ratio drifting toward 2.
#define HALL_ENTRY_MARGIN_COUNTS   45
#define HALL_MIN_PEAK_DELTA        35

// ---------------------------------------------------------------------------
// CTO3 Station Stop: the v1 Arches-only filter (MISSION_ONLY_STATION,
// 2026-08-08) was REMOVED here by operator direction 2026-08-08 after the
// inaugural Arches cycle validated the phase chain — all four stations now
// arm with their existing R21 profiles. The stationEnabled() mechanism
// remains in the sketch for future missions.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// 2026-08-21 TRIAL: quarantine physical floor 350 -> 500 ms, Otto only.
// Operator direction. Rationale and bound recorded at Q_FLOOR_MS in QUORUM.ino:
// shortest map interval 280 mm, fleet maximum measured 400 mm/s = 700 ms, so
// 500 ms implies 560 mm/s and keeps a 1.4x margin. Toby stays at 350 as the
// control.
//
// What this buys: the quarantine's three criteria (weak, too soon, opposite
// polarity) currently only vote below 0.40 x median interval ~= 400 ms, while
// the absolute floor already rejects below 350 ms. Raising the floor covers
// the 350-500 ms band outright.
//
// What it risks: dt is measured from the last RECEIVED event, phantoms
// included, so a genuine magnet arriving within 500 ms of a phantom is
// quarantined - and quarantine's ambiguous default is PHANTOM (2026-08-20:
// 3 committed against 60 discarded). A wrongly quarantined marker becomes a
// missed marker and a position lag. Watch for quorum adopting POSITIVE offsets.
// ---------------------------------------------------------------------------
#define Q_FLOOR_MS_OVERRIDE 500

// ---------------------------------------------------------------------------
// NAVI_ONE recognizer — MEASURED ON OTTO, and on Otto only.
//
// Source: field-records/logs/20260909_survey/, Otto's bidirectional Hall
// survey on the new external-antenna board at PWM 90, CW and CCW, full 171-
// position coverage. The hardware-consistency cutoff is absolute and was
// applied: nothing before the 21:04:17 boot on 2026-09-09 enters any figure
// below. Derivation is written up in
// docs/NAVI_CTO_ARCHITECTURE_AND_PROVENANCE_20260909.md section 3.
//
// These are NOT Toby's numbers rescaled. Otto enters at 70 counts against
// Toby's 38 — a materially different sensor environment — and every value here
// comes from Otto's own waveforms. NAVI_RECOGNIZER_MEASURED_ON is checked
// against LOCO_ID at compile time so this cannot be inherited by accident.
// ---------------------------------------------------------------------------

// IR PRESENCE IS DECLARED, NOT PROBED. Operator declaration 2026-09-09: Otto
// carries no wheel sensor on pin 34. 0 leaves the pin untouched, which is also
// what keeps floating-input crosstalk off the Hall line.
//
// This says nothing about the towed IR test car, which is a different
// instrument on a different vehicle and reaches the locomotive over ESP-NOW,
// not over pin 34. As of 2026-09-10 that car is not producing usable counts
// (field-records/20260910_IR_CAR_BENCH_WHEEL_TEST.md); NAVI_ONE does not
// consume it in any case.
#define IR_FITTED 0

#define NAVI_RECOGNIZER_MEASURED_ON  9950011UL
#define NAVI_GUARD_MS                500U     // operator ruling 2026-09-10; decision 0057
#define NAVI_AMPLITUDE_FLOOR         0.34f    // 0.34 x 173 = 59, inside the 33->144 gap
#define NAVI_RESIDUAL_CEILING        0.13f    // diagnostic reference; it cannot refuse
#define NAVI_BOOTSTRAP_GAIN          175U     // Otto's combined median accepted peak
#define NAVI_AUTO_CRUISE_PWM         90       // the surveyed regime

// ---------------------------------------------------------------------------
// STATION APPROACH MARKER TIMES — how long OTTO takes to cross one marker at
// each step of a station approach, from -10 to -6. Milliseconds.
//
// Obtained by NAVI_ONE's own stated method, the one used for Toby: a measured
// marker time at PWM 90, scaled by speed proportional to (PWM - intercept).
// Otto's measured figure is 1,158 ms per marker; his fit
//
//     speed_mm_s = 3.872 x (PWM - 23.6)
//
// comes from 4,959 phantom-filtered MOVING rows across 34 PWM bins and
// predicts that 1,158 ms to +0.8%.
//
// Corroboration that these are Otto's and not a copy: Toby's profile fit
// predicts 1,159 ms where Toby actually runs 1,326 (-12.6%). The fit recorded
// in Toby's profile describes Otto, not Toby. Recorded in section 3.9 of the
// provenance report; Toby's own numbers are left exactly as they are.
#define NAVI_APPROACH_MARKER_MS   { 1213, 1340, 1496, 1694, 1952 }

// ---------------------------------------------------------------------------
// BASELINE ADAPTATION FLOOR — the PWM at or below which the Hall reference is
// frozen. OTTO'S OWN INTERCEPT: 23.6 from the fit above, rounded UP to 24 so
// the gate errs one count toward freezing rather than toward adapting on a
// locomotive that may not be moving. Toby's 25 is his and stays his.
#define NAVI_BASELINE_ADAPT_PWM   24
