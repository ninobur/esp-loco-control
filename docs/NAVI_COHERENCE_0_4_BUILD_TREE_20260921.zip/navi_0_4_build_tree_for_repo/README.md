# NAVI_COHERENCE 0.4 — review build tree

The exact file set used to independently compile and verify
`firmware/NAVI_COHERENCE/NAVI_COHERENCE_0_4_patch.zip` for
[docs/NAVI_COHERENCE_0_4_INDEPENDENT_REVIEW_20260921.md](../NAVI_COHERENCE_0_4_INDEPENDENT_REVIEW_20260921.md).
Not a new firmware artifact — a snapshot of where each file came from, kept
so the same build can be reproduced without re-deriving the dependency list.

## Layout and provenance

The `test-programs/` layout mirrors the real repo so the vendored headers'
relative includes (`../NAVI_SIMPLIFIED/...`, `../NAVI_ONE_X22/...`,
`../../common/...`, `../../QUORUM/credentials.h`) resolve unmodified.

| Path here | Source in the repo |
|---|---|
| `test-programs/NAVI_COHERENCE_0_4/*.ino`, `Navigator.h`, `RecoveryControl.h`, `test_coherence.cpp` | `firmware/NAVI_COHERENCE/NAVI_COHERENCE_0_4_patch.zip` (the patch under review) |
| `test-programs/NAVI_COHERENCE_0_4/{RouteMap,MovementEvidence,Ops,Stations,HallObserver,LocoConfig}.h` | `firmware/test-programs/NAVI_IR/` (shared deps the patch's own README names but doesn't ship) |
| `test-programs/NAVI_SIMPLIFIED/LL_LocoConfig_995001{1,2}.h` | `firmware/test-programs/NAVI_SIMPLIFIED/` (reached via `LocoConfig.h`) |
| `test-programs/NAVI_ONE_X22/{ExcursionDetector,MagnetRecognizer}.h` | `firmware/test-programs/NAVI_ONE_X22/` (reached via `HallObserver.h`) |
| `common/*.h` | `firmware/common/` |
| `QUORUM/credentials.h.template` | **Not** the real `firmware/QUORUM/credentials.h` — that file is git-ignored repo-wide (`.gitignore`: `credentials.h`, `firmware/*/credentials.h`) because it holds real WiFi credentials in plain text, so it was never bundled. This is `firmware/config/credentials_template.h` instead. |

## To rebuild

```
cp QUORUM/credentials.h.template QUORUM/credentials.h
# edit QUORUM/credentials.h: fill in your real WIFI_SSID / WIFI_PASS
arduino-cli compile --fqbn esp32:esp32:esp32 --warnings all --clean test-programs/NAVI_COHERENCE_0_4
g++ -std=c++17 -Wall -Wextra -fsanitize=address,undefined -o /tmp/test_coherence test-programs/NAVI_COHERENCE_0_4/test_coherence.cpp && /tmp/test_coherence
```

Expect: 0 warnings from NAVI_COHERENCE (3 unrelated pre-existing warnings
from the vendored Adafruit_INA219 library are normal), and the host test
binary prints a pass line and exits 0. See the review doc for the full
verification record, including the ASan reproduction of the fixed
`publishNav()`/`publishDecision()` format strings.

Verification copy only — not the authoritative source for any of these
files. The MQTT broker address is hardcoded directly in the `.ino` itself
(a LAN-internal address, already present in the patch as given), not part
of credentials.
