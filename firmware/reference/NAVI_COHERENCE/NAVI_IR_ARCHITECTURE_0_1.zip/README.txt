NAVI IR architecture 0.1 — 2026-09-22

PURPOSE
-------
First C++ architecture pass implementing the design recorded in decision 0094.

This is intentionally NOT a revised NAVI_COHERENCE sketch yet.

The package contains three independent concepts:

1. IrHealth.h
   "Can the instrument measure?"

2. IrOdometry.h
   "We have moved this much."

3. MmDistanceReference.h
   "Distance from which known MM?"

NAVI remains the component that answers:
   "This is where we are."

IMPORTANT DESIGN BOUNDARIES
---------------------------
- Zero movement is data, not a health failure.
- SIGNAL_STALE has no health authority.
- TRACKING is not synonymous with IR validity.
- IR does not determine map position.
- A real IR failure breaks continuity across the blind interval.
- IR health recovery immediately restores new movement/distance measurement.
- Distance from the OLD MM remains unavailable after a blind interval.
- A later independently accepted MM establishes a new MM distance reference.
- Normal stop/dwell does not break odometry or MM reference continuity.

NOT YET DONE
------------
- No changes to NAVI_COHERENCE_0_5 source.
- No NAVI state/action logic.
- No Hall changes.
- No 70-count change.
- No 650-ms guard change.
- No +/-15% window changes.
- No AUTO/station changes.
- No position-recovery changes.
- No telemetry integration yet.

REVIEW NOTE
-----------
This is architecture-first code. The next step should be review of each class
and its invariants before connecting it to MovementEvidence/Navigator.
