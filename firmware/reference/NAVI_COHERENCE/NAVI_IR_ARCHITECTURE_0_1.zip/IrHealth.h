#pragma once
#include <stdint.h>
#include "../../common/IrMovementWire.h"

namespace ngr_nav {

enum class IrUnavailableReason : uint8_t {
  None = 0,
  NoSource,
  LinkStale,
  PacketInvalid,
  OrderFault,
  CalibrationFault,
  InadequateContrast,
  Saturation,
  SampleGap,
  PulseFault
};

struct IrHealth {
  bool available = false;
  IrUnavailableReason reason = IrUnavailableReason::NoSource;
};

inline const char* irUnavailableReasonName(IrUnavailableReason r) {
  switch (r) {
    case IrUnavailableReason::None:               return "NONE";
    case IrUnavailableReason::NoSource:           return "NO_SOURCE";
    case IrUnavailableReason::LinkStale:          return "LINK_STALE";
    case IrUnavailableReason::PacketInvalid:      return "PACKET_INVALID";
    case IrUnavailableReason::OrderFault:         return "ORDER_FAULT";
    case IrUnavailableReason::CalibrationFault:   return "CALIBRATION_FAULT";
    case IrUnavailableReason::InadequateContrast: return "INADEQUATE_CONTRAST";
    case IrUnavailableReason::Saturation:         return "SATURATION";
    case IrUnavailableReason::SampleGap:          return "SAMPLE_GAP";
    case IrUnavailableReason::PulseFault:         return "PULSE_FAULT";
    default:                                      return "UNKNOWN";
  }
}

// Classify the measuring instrument only.
// Movement (including zero movement) is deliberately NOT a health input.
//
// SIGNAL_STALE is intentionally not a health failure. The current detector uses
// that value when no pulse has completed recently. Fresh packets with an
// unchanged counter are valid zero incremental movement.
//
// REACQUIRING and PRIMING are not failures either. They mean the optical pulse
// detector does not yet have a completed pulse history. The stream may still be
// structurally valid; distance availability is determined by odometry/reference
// continuity rather than by pretending the instrument is broken.
inline IrHealth classifyIrHealth(const ir_movement::WireSnapshot& w) {
  IrHealth h;

  if (!w.bootId || !w.pitchUm || !w.calibrationId) {
    h.reason = IrUnavailableReason::CalibrationFault;
    return h;
  }

  switch (w.opticalReason) {
    case ir_movement::INADEQUATE_CONTRAST:
      h.reason = IrUnavailableReason::InadequateContrast;
      return h;
    case ir_movement::SATURATION:
      h.reason = IrUnavailableReason::Saturation;
      return h;
    case ir_movement::SAMPLE_GAP:
      h.reason = IrUnavailableReason::SampleGap;
      return h;

    // These describe pulse/movement state, not instrument failure.
    case ir_movement::PRIMING:
    case ir_movement::SIGNAL_STALE:
    case ir_movement::REACQUIRING:
    case ir_movement::TRACKING:
      h.available = true;
      h.reason = IrUnavailableReason::None;
      return h;
    default:
      h.reason = IrUnavailableReason::PacketInvalid;
      return h;
  }
}

} // namespace ngr_nav
