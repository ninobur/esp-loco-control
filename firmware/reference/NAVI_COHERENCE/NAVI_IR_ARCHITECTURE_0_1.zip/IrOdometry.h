#pragma once
#include <stdint.h>
#include "../../common/IrMovementWire.h"
#include "IrHealth.h"

namespace ngr_nav {

// IR answers only: "we have moved this much."
// It does not know MM identity, map position, station state, PWM intent,
// derailment, wheel slip, or whether the locomotive progressed along the track.
class IrOdometry {
 public:
  void reset() {
    have_ = false;
    continuous_ = false;
    bootId_ = 0;
    calibrationId_ = 0;
    pitchUm_ = 0;
    pulses_ = 0;
    capturedUs_ = 0;
  }

  // A real measurement failure breaks continuity across the blind interval.
  // Later healthy samples can resume odometry from a new local origin, but
  // cannot reconstruct distance that may have occurred while blind.
  void breakContinuity() { continuous_ = false; }

  bool ingest(const ir_movement::WireSnapshot& w, const IrHealth& health) {
    if (!health.available) {
      breakContinuity();
      return false;
    }

    if (!have_) {
      adopt(w);
      have_ = true;
      // First healthy snapshot is an origin, not proof of continuity with
      // anything that happened before it.
      continuous_ = true;
      return true;
    }

    if (w.bootId != bootId_ ||
        w.calibrationId != calibrationId_ ||
        w.pitchUm != pitchUm_ ||
        w.capturedUs <= capturedUs_ ||
        w.completedPulses < pulses_) {
      adopt(w);
      continuous_ = false;
      return false;
    }

    pulses_ = w.completedPulses;
    capturedUs_ = w.capturedUs;
    return true;
  }

  bool haveMeasurement() const { return have_; }
  bool continuous() const { return have_ && continuous_; }

  uint64_t pulses() const { return pulses_; }
  uint64_t capturedUs() const { return capturedUs_; }
  uint32_t pitchUm() const { return pitchUm_; }
  uint64_t bootId() const { return bootId_; }
  uint32_t calibrationId() const { return calibrationId_; }

  double totalMm() const {
    return have_ ? double(pulses_) * double(pitchUm_) / 1000.0 : 0.0;
  }

 private:
  void adopt(const ir_movement::WireSnapshot& w) {
    bootId_ = w.bootId;
    calibrationId_ = w.calibrationId;
    pitchUm_ = w.pitchUm;
    pulses_ = w.completedPulses;
    capturedUs_ = w.capturedUs;
  }

  bool have_ = false;
  bool continuous_ = false;
  uint64_t bootId_ = 0;
  uint32_t calibrationId_ = 0;
  uint32_t pitchUm_ = 0;
  uint64_t pulses_ = 0;
  uint64_t capturedUs_ = 0;
};

} // namespace ngr_nav
