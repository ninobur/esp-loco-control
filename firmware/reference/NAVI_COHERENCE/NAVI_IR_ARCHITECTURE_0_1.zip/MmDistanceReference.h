#pragma once
#include <stdint.h>
#include "IrOdometry.h"

namespace ngr_nav {

// NAVI answers: "this is where we are."
//
// This object does not create distance. IR already measures distance.
// It associates IR odometry with a known mapped landmark.
//
// A reference is:
//   MM identity + Hall detection timestamp + corresponding IR count.
//
// If IR continuity is broken, the reference is invalid until NAVI independently
// accepts a later MM and establishes a new reference there.
class MmDistanceReference {
 public:
  void invalidate() { valid_ = false; }

  bool establish(uint8_t mm,
                 uint32_t hallDetectedAtMs,
                 const IrOdometry& odo) {
    if (!odo.haveMeasurement() || !odo.continuous()) {
      valid_ = false;
      return false;
    }
    valid_ = true;
    mm_ = mm;
    hallDetectedAtMs_ = hallDetectedAtMs;
    irCapturedUs_ = odo.capturedUs();
    pulseCount_ = odo.pulses();
    pitchUm_ = odo.pitchUm();
    bootId_ = odo.bootId();
    calibrationId_ = odo.calibrationId();
    return true;
  }

  bool validFor(const IrOdometry& odo) const {
    return valid_ &&
           odo.haveMeasurement() &&
           odo.continuous() &&
           odo.bootId() == bootId_ &&
           odo.calibrationId() == calibrationId_ &&
           odo.pitchUm() == pitchUm_ &&
           odo.pulses() >= pulseCount_;
  }

  double distanceFromMm(const IrOdometry& odo) const {
    if (!validFor(odo)) return 0.0;
    return double(odo.pulses() - pulseCount_) * double(pitchUm_) / 1000.0;
  }

  bool valid() const { return valid_; }
  uint8_t mm() const { return mm_; }
  uint32_t hallDetectedAtMs() const { return hallDetectedAtMs_; }
  uint64_t irCapturedUs() const { return irCapturedUs_; }
  uint64_t pulseCount() const { return pulseCount_; }

 private:
  bool valid_ = false;
  uint8_t mm_ = 0;
  uint32_t hallDetectedAtMs_ = 0;
  uint64_t irCapturedUs_ = 0;
  uint64_t pulseCount_ = 0;
  uint32_t pitchUm_ = 0;
  uint64_t bootId_ = 0;
  uint32_t calibrationId_ = 0;
};

} // namespace ngr_nav
