# NAVI_IR 0.3 delta

This patch is intended to be applied over the existing NAVI_IR 0.2 folder. It changes only `NAVI_IR.ino`, `Navigator.h`, and `HypothesisNavigator.h`; retain the existing `MovementEvidence.h`, `HallObserver.h`, `RecoveryControl.h`, `RouteMap.h`, `Stations.h`, `Ops.h`, and `LocoConfig.h`.

## Operator decisions implemented

- NAV remains primary. Missing/unusable IR does not prevent a clean Hall/map advance.
- The first correctly accepted Hall landmark becomes the IR map/odometer anchor.
- IR earns independent confidence after 10 consecutive one-map-span distance agreements.
- Existing 500 ms timing exclusion is retained as a temporary Hall reality gate.
- Valid IR adds a hard **too-early** gate: if travel is still closer to zero mapped intervals than to the next mapped landmark (midpoint rule), the Hall event cannot advance NAV and is retained as a false observation.
- No +/- percentage accuracy is asserted by that gate.
- Once IR is confident, terminal navigation loss first attempts an IR map reseed from the last accepted Hall/IR anchor. IR proposes the nearest one or two mapped candidates; Hall polarity must corroborate them. IR alone never names or advances a marker.
- Manual running is not stopped merely because NAV is evaluating/relocalizing. AUTO remains gated as in 0.2.
- Telemetry adds IR confidence and predicted-next-MM/time fields, and `nav/ir_compare` reports `TIMING_TOO_EARLY`, `IR_TOO_EARLY`, or `IR_POSSIBLE` where applicable.

## Deliberately provisional

The midpoint IR gate is a conservative classification rule, not a certified odometry error bound. Recovery candidate width is currently two nearest mapped positions. Prediction time uses the most recent usable IR Hall-to-Hall interval speed. Field evidence should be used to revise these mechanisms rather than silently fitting the map.

## Verification performed here

A focused native C++ test of the modified navigator passed for: first-Hall anchoring, 10-interval IR confidence acquisition, IR too-early rejection, and the 500 ms timing gate. A full Arduino/ESP32 compile was not available in this environment because the repository's complete Arduino dependency tree and common headers were not supplied here. Run the repository's existing host suite and `arduino-cli compile` before flashing.
