#pragma once
#include "HypothesisNavigator_0_3.h"

namespace navi_one {
struct NavObservation {
  uint32_t openedAtMs=0;
  uint8_t polarity=0,windowPolarity=0;
  bool directionConflict=false,restartUncertain=false,windowValid=false;
  ngr_nav::MotionPoint movement{};
};
enum class NavState : uint8_t { Unset, Declared, WaitingDistance, Unresolved, LimitStopped };
inline const char* navStateName(NavState s) {
  switch(s) {
    case NavState::Declared:return "TRACKING";
    case NavState::WaitingDistance:return "WAITING_DISTANCE";
    case NavState::Unresolved:return "AMBIGUOUS";
    case NavState::LimitStopped:return "LOST";
    default:return "UNSET";
  }
}
// EVALUATING retains a last-known reference, not authority to advance or drive.
inline const char* consoleNavName(NavState s) {
  switch(s) {
    case NavState::Declared:return "NORMAL";
    case NavState::WaitingDistance:
    case NavState::Unresolved:return "EVALUATING";
    case NavState::LimitStopped:return "LOST";
    default:return "UNSET";
  }
}
inline bool consoleHasReference(NavState s) {
  return s==NavState::Declared || s==NavState::WaitingDistance || s==NavState::Unresolved;
}
enum class Ruling : uint8_t {
  Advanced, NoPosition, WaitingDistance, Ambiguous, Reestablished, UnresolvedLimitStop, Retained, IrReseeded
};
inline const char* rulingName(Ruling s) {
  switch(s) {
    case Ruling::Advanced:return "ADVANCED";
    case Ruling::WaitingDistance:return "WAITING_DISTANCE";
    case Ruling::Ambiguous:return "AMBIGUOUS";
    case Ruling::Reestablished:return "REESTABLISHED";
    case Ruling::UnresolvedLimitStop:return "RECOVERY_EXHAUSTED";
    case Ruling::Retained:return "FALSE_OBSERVATION";
    case Ruling::IrReseeded:return "IR_RESEEDED";
    default:return "NO_POSITION";
  }
}
enum class Trust : uint8_t { Declared, Sequence };
inline const char* trustName(Trust t){return t==Trust::Sequence?"CONDITIONAL_SEQUENCE":"DECLARED";}
struct NavStatus {
  NavState state=NavState::Unset;
  uint8_t navMm=0,target=0;
  int8_t navDir=0;
  Trust trust=Trust::Declared;
  uint32_t advances=0,refusals=0,irWaits=0;
  uint8_t unresolvedCount=0,sequenceLength=0;
  uint16_t sequenceMatches=0;
  bool distanceConfirmed=false,distanceAssessable=false;
  bool irConfident=false;
  uint8_t irConfidence=0;
  uint8_t irPredictedMm=0;
  uint32_t irPredictedAtMs=0;
  bool irPredictionValid=false;
  ngr_nav::MotionIssue irIssue=ngr_nav::MotionIssue::NoSource;
};
class Navigator {
 public:
  const NavStatus& status() const{return s_;}
  const navi_hypothesis::HypothesisNavigator& hypotheses() const{return core_;}
  bool positionKnown() const{return s_.state==NavState::Declared;}
  bool unresolved() const{return s_.state==NavState::Unresolved;}
  bool waitingDistance() const{return s_.state==NavState::WaitingDistance;}
  bool evaluating() const{return unresolved() || waitingDistance();}
  bool takeResetRequest(){bool r=reset_;reset_=false;return r;}
  void haltForLoss(){s_.state=NavState::LimitStopped;s_.distanceConfirmed=false;}
  void declare(uint8_t mm,int8_t dir) {
    s_=NavStatus{};s_.navMm=mm;s_.navDir=dir;s_.target=nextMarker(mm,dir);
    core_.declare(mm,dir,0);s_.state=dir?NavState::Declared:NavState::Unset;
    haveGoodAnchor_=false; irConfident_=false; irConfidence_=0;
    reset_=true;recoveryActive_=false;
  }
  // Unsigned wheel movement cannot establish a reversed route frame.
  void setDirection(int8_t dir) {
    if(dir!=s_.navDir) {
      s_.navDir=dir;s_.target=nextMarker(s_.navMm,dir);s_.state=NavState::Unset;
      s_.distanceConfirmed=false;s_.distanceAssessable=false;reset_=true;
    }
  }
  Ruling judge(const NavObservation& p) {
    if(s_.state==NavState::Unset || s_.state==NavState::LimitStopped)return Ruling::NoPosition;
    if(p.directionConflict) {
      s_.state=NavState::Unset;s_.distanceConfirmed=false;s_.distanceAssessable=false;
      return Ruling::NoPosition;
    }
    const bool wasEvaluating=evaluating();
    navi_hypothesis::Observation o;
    o.atMs=p.openedAtMs;o.openingPolarity=p.polarity;o.windowPolarity=p.windowPolarity;
    o.windowValid=p.windowValid;o.movement=p.movement;
    const auto result=core_.observe(o);
    s_.sequenceMatches=core_.count();
    s_.distanceConfirmed=s_.distanceAssessable=core_.count()>0;
    s_.irIssue=ngr_nav::MotionIssue::None;
    for(uint8_t i=0;i<core_.count();++i) {
      const auto& h=core_.hypothesis(i);
      if(!h.distanceAgrees)s_.distanceConfirmed=false;
      if(h.distanceIssue!=ngr_nav::MotionIssue::None) {
        s_.distanceAssessable=false;
        if(s_.irIssue==ngr_nav::MotionIssue::None)s_.irIssue=h.distanceIssue;
      }
    }
    if(result==navi_hypothesis::Result::Lost) {
      // 0.3: LOST is a request for IR-backed relocalization, not surrender.
      // IR proposes candidate map positions from the last accepted Hall/IR
      // anchor; this same Hall observation must still match candidate polarity.
      if(irConfident_ && haveGoodAnchor_ &&
         core_.reseedFromIr(goodMm_,goodMovement_,o)) {
        s_.sequenceMatches=core_.count();
        if(core_.positionCertain()) {
          const uint8_t mm=core_.position();
          s_.navMm=mm;s_.target=nextMarker(mm,s_.navDir);s_.state=NavState::Declared;
          s_.unresolvedCount=0;recoveryActive_=false;++s_.advances;
          goodMm_=mm;goodMovement_=p.movement;goodAtMs_=p.openedAtMs;haveGoodAnchor_=true;
          updateIrPrediction();
          return Ruling::IrReseeded;
        }
        s_.state=NavState::Unresolved;
        return Ruling::Ambiguous;
      }
      haltForLoss();return Ruling::UnresolvedLimitStop;
    }
    if(!s_.distanceAssessable)++s_.irWaits;
    // 0.3: NAV remains primary. Missing IR does not prevent a clean Hall/map
    // advance. IR owns its own confidence and simply withholds its gate/recovery
    // authority until it has ten consecutive map-consistent intervals.
    if(result==navi_hypothesis::Result::Ambiguous) {
      s_.state=NavState::Unresolved;++s_.refusals;
      // Sensor loss pauses (but does not renew) this budget. It cannot grant
      // an advance. All retained interpretations must be distance-assessable.
      if(s_.distanceAssessable) {
        if(recoveryActive_)++s_.unresolvedCount;
        else {recoveryActive_=true;s_.unresolvedCount=0;}
      }
      if(s_.unresolvedCount>=10){
        if(irConfident_ && haveGoodAnchor_ && core_.reseedFromIr(goodMm_,goodMovement_,o)) {
          s_.unresolvedCount=0;recoveryActive_=false;
          if(core_.positionCertain()) {
            const uint8_t mm=core_.position();s_.navMm=mm;s_.target=nextMarker(mm,s_.navDir);
            s_.state=NavState::Declared;goodMm_=mm;goodMovement_=p.movement;goodAtMs_=p.openedAtMs;
            updateIrPrediction();return Ruling::IrReseeded;
          }
          s_.state=NavState::Unresolved;return Ruling::Ambiguous;
        }
        haltForLoss();return Ruling::UnresolvedLimitStop;
      }
      return Ruling::Ambiguous;
    }
    const uint8_t mm=core_.position();const bool advanced=mm!=s_.navMm;
    s_.navMm=mm;s_.target=nextMarker(mm,s_.navDir);s_.state=NavState::Declared;
    s_.unresolvedCount=0;recoveryActive_=false;
    // First accepted Hall event establishes the IR odometer/map anchor.
    // Thereafter ten consecutive one-map-span agreements establish IR confidence.
    if(advanced) {
      if(!haveGoodAnchor_) {
        goodMm_=mm;goodMovement_=p.movement;goodAtMs_=p.openedAtMs;haveGoodAnchor_=true;
        irConfidence_=0;irConfident_=false;
      } else {
        const auto interval=ngr_nav::between(goodMovement_,p.movement);
        const double expected=navi_one::spanMm(goodMm_,s_.navDir);
        bool agrees=false;
        if(interval.usable()) {
          const uint32_t dt=p.openedAtMs-goodAtMs_;
          if(dt)lastIrSpeedMmS_=uint32_t(interval.nominalMm*1000.0/dt);
          // Midpoint classification: closer to the expected one-span distance
          // than to zero or to the following two-span distance. No +/- percent
          // accuracy is claimed.
          const double two=expected+navi_one::spanMm(mm,s_.navDir);
          const double e1=interval.nominalMm>expected?interval.nominalMm-expected:expected-interval.nominalMm;
          const double e0=interval.nominalMm;
          const double e2=interval.nominalMm>two?interval.nominalMm-two:two-interval.nominalMm;
          agrees=e1<e0 && e1<e2;
        }
        if(agrees) { if(irConfidence_<10)++irConfidence_; }
        else { irConfidence_=0; irConfident_=false; }
        if(irConfidence_>=10)irConfident_=true;
        goodMm_=mm;goodMovement_=p.movement;goodAtMs_=p.openedAtMs;
      }
      updateIrPrediction();
    }
    s_.irConfidence=irConfidence_;s_.irConfident=irConfident_;
    s_.sequenceLength=irConfidence_;
    if(irConfident_)s_.trust=Trust::Sequence;
    if(advanced)++s_.advances;
    return wasEvaluating?Ruling::Reestablished:advanced?Ruling::Advanced:Ruling::Retained;
  }
 private:
  void updateIrPrediction(){
    s_.irPredictionValid=false;
    if(!irConfident_ || !haveGoodAnchor_ || !lastIrSpeedMmS_)return;
    s_.irPredictedMm=nextMarker(goodMm_,s_.navDir);
    s_.irPredictedAtMs=goodAtMs_ +
      uint32_t((uint64_t(navi_one::spanMm(goodMm_,s_.navDir))*1000ULL)/lastIrSpeedMmS_);
    s_.irPredictionValid=true;
  }
  navi_hypothesis::HypothesisNavigator core_;
  NavStatus s_{};bool reset_=false,recoveryActive_=false;
  bool haveGoodAnchor_=false,irConfident_=false;
  uint8_t goodMm_=0,irConfidence_=0;
  uint32_t goodAtMs_=0,lastIrSpeedMmS_=0;
  ngr_nav::MotionPoint goodMovement_{};
};
}
