#pragma once
#include <stdint.h>
#include "RouteMap.h"
#include "MovementEvidence.h"

namespace navi_one {
static constexpr uint32_t MIN_MARKER_MS=500;
static constexpr uint8_t RECOVERY_WORD=10;
static constexpr uint8_t MAX_UNCONFIRMED_MARKERS=10;

enum class EvidenceClass:uint8_t{None,Confirmed,NonLandmarkHall,PolarityDiscrepancy,MissedMarker,IrUnavailable,ModelUncertain,SequenceRecovered};
inline const char* evidenceClassName(EvidenceClass e){switch(e){case EvidenceClass::Confirmed:return "CONFIRMED";case EvidenceClass::NonLandmarkHall:return "NON_LANDMARK_HALL";case EvidenceClass::PolarityDiscrepancy:return "POLARITY_DISCREPANCY";case EvidenceClass::MissedMarker:return "MISSED_MARKER";case EvidenceClass::IrUnavailable:return "IR_UNAVAILABLE";case EvidenceClass::ModelUncertain:return "MODEL_UNCERTAIN";case EvidenceClass::SequenceRecovered:return "SEQUENCE_RECOVERED";default:return "NONE";}}
struct NavObservation{uint32_t openedAtMs=0;uint8_t polarity=0,windowPolarity=0;bool directionConflict=false,restartUncertain=false,windowValid=false;ngr_nav::MotionPoint movement{};};
enum class NavState:uint8_t{Unset,Tracking,Uncertain,Lost};
inline const char* navStateName(NavState s){switch(s){case NavState::Tracking:return "TRACKING";case NavState::Uncertain:return "UNCERTAIN";case NavState::Lost:return "LOST";default:return "UNSET";}}
inline const char* consoleNavName(NavState s){switch(s){case NavState::Tracking:return "NORMAL";case NavState::Uncertain:return "EVALUATING";case NavState::Lost:return "LOST";default:return "UNSET";}}
inline bool consoleHasReference(NavState s){return s==NavState::Tracking||s==NavState::Uncertain;}
enum class Ruling:uint8_t{Advanced,NoPosition,NonLandmark,MissedAndAdvanced,AdvancedWithDiscrepancy,Uncertain,Reestablished,Retained};
inline const char* rulingName(Ruling r){switch(r){case Ruling::Advanced:return "ADVANCED";case Ruling::NonLandmark:return "NON_LANDMARK_HALL";case Ruling::MissedAndAdvanced:return "MISSED_AND_ADVANCED";case Ruling::AdvancedWithDiscrepancy:return "ADVANCED_WITH_DISCREPANCY";case Ruling::Uncertain:return "UNCERTAIN";case Ruling::Reestablished:return "REESTABLISHED";case Ruling::Retained:return "RETAINED";default:return "NO_POSITION";}}
enum class Trust:uint8_t{OperatorDeclared,Continuity,SequenceRecovered};
inline const char* trustName(Trust t){return t==Trust::Continuity?"CONTINUITY":t==Trust::SequenceRecovered?"SEQUENCE_RECOVERED":"OPERATOR_DECLARED";}
struct NavStatus{NavState state=NavState::Unset;uint8_t navMm=0,target=0;int8_t navDir=0;Trust trust=Trust::OperatorDeclared;EvidenceClass evidence=EvidenceClass::None;uint32_t advances=0,refusals=0,irWaits=0;uint8_t unresolvedCount=0,sequenceLength=0;uint16_t sequenceMatches=0;uint8_t missedSinceLast=0;bool distanceConfirmed=false,distanceAssessable=false;ngr_nav::MotionIssue irIssue=ngr_nav::MotionIssue::NoSource;};
struct PositionEvidence{uint8_t mm=0;uint32_t lastRealMs=0;uint8_t faults=0,causes=0,clean=0;bool distanceAgrees=false;ngr_nav::MotionIssue distanceIssue=ngr_nav::MotionIssue::NoSource;ngr_nav::MotionPoint movement{};};
class PositionView{public:uint8_t count()const{return valid_?1:0;}const PositionEvidence& hypothesis(uint8_t)const{return p_;}int8_t direction()const{return dir_;}void set(bool v,uint8_t mm,int8_t d,uint32_t at,const ngr_nav::MotionPoint&m,bool ok,ngr_nav::MotionIssue issue,uint8_t clean){valid_=v;dir_=d;p_.mm=mm;p_.lastRealMs=at;p_.movement=m;p_.distanceAgrees=ok;p_.distanceIssue=issue;p_.clean=clean;}private:bool valid_=false;int8_t dir_=0;PositionEvidence p_{};};

class Navigator{
public:
 const NavStatus& status()const{return s_;} const PositionView& hypotheses()const{return view_;}
 bool positionKnown()const{return s_.state==NavState::Tracking;} bool unresolved()const{return s_.state==NavState::Uncertain;} bool evaluating()const{return unresolved();}
 bool takeResetRequest(){bool r=reset_;reset_=false;return r;} void haltForLoss(){s_.state=NavState::Lost;s_.distanceConfirmed=false;refreshView();}
 void declare(uint8_t mm,int8_t dir){s_=NavStatus{};s_.navMm=mm;s_.navDir=dir;s_.target=nextMarker(mm,dir);s_.state=dir?NavState::Tracking:NavState::Unset;s_.trust=Trust::OperatorDeclared;haveAnchor_=false;lastAcceptedMs_=0;historyCount_=historyHead_=0;reset_=true;refreshView();}
 void setDirection(int8_t dir){if(dir==s_.navDir)return;s_.navDir=dir;s_.target=nextMarker(s_.navMm,dir);s_.state=NavState::Unset;haveAnchor_=false;historyCount_=historyHead_=0;reset_=true;refreshView();}
 Ruling judge(const NavObservation&o){
  if(s_.state==NavState::Unset||s_.state==NavState::Lost)return Ruling::NoPosition;
  if(o.directionConflict||!s_.navDir){s_.state=NavState::Unset;haveAnchor_=false;refreshView();return Ruling::NoPosition;}
  s_.evidence=EvidenceClass::None;s_.missedSinceLast=0;s_.distanceAssessable=false;s_.distanceConfirmed=false;s_.irIssue=o.movement.issue;
  if(s_.state==NavState::Uncertain){
   if(lastAcceptedMs_&&uint32_t(o.openedAtMs-lastAcceptedMs_)<MIN_MARKER_MS){++s_.refusals;s_.evidence=EvidenceClass::NonLandmarkHall;refreshView();return Ruling::NonLandmark;}
   pushPolarity(o.polarity);lastAcceptedMs_=o.openedAtMs;uint8_t recovered=0;
   if(uniqueHistoryMatch(recovered)){s_.navMm=recovered;s_.target=nextMarker(recovered,s_.navDir);s_.state=NavState::Tracking;s_.trust=Trust::SequenceRecovered;s_.evidence=EvidenceClass::SequenceRecovered;s_.unresolvedCount=0;s_.sequenceLength=RECOVERY_WORD;s_.sequenceMatches=RECOVERY_WORD;if(o.movement.issue==ngr_nav::MotionIssue::None){anchorMovement_=o.movement;haveAnchor_=true;}anchorMm_=recovered;anchorMs_=o.openedAtMs;lastAcceptedMs_=o.openedAtMs;refreshView();return Ruling::Reestablished;}
   if(s_.unresolvedCount<255){++s_.unresolvedCount;} s_.evidence=EvidenceClass::ModelUncertain;refreshView();return Ruling::Uncertain;
  }
  if(!haveAnchor_){uint8_t expected=s_.target;bool pol=hallSupports(o,polarityAt(expected));accept(expected,o,0,pol?EvidenceClass::Confirmed:EvidenceClass::PolarityDiscrepancy);return pol?Ruling::Advanced:Ruling::AdvancedWithDiscrepancy;}
  uint32_t elapsed=o.openedAtMs-anchorMs_;auto interval=ngr_nav::between(anchorMovement_,o.movement);s_.distanceAssessable=interval.usable();s_.irIssue=interval.issue;if(!interval.usable())++s_.irWaits;
  if(elapsed<MIN_MARKER_MS){++s_.refusals;s_.evidence=EvidenceClass::NonLandmarkHall;refreshView();return Ruling::NonLandmark;}
  uint8_t steps=1;
  if(interval.usable()){steps=nearestForwardMarker(interval.nominalMm);if(steps==0){++s_.refusals;s_.evidence=EvidenceClass::NonLandmarkHall;s_.distanceConfirmed=true;refreshView();return Ruling::NonLandmark;}if(steps>MAX_UNCONFIRMED_MARKERS){s_.state=NavState::Uncertain;s_.evidence=EvidenceClass::ModelUncertain;s_.unresolvedCount=1;historyCount_=historyHead_=0;pushPolarity(o.polarity);refreshView();return Ruling::Uncertain;}}
  uint8_t mm=s_.navMm;for(uint8_t i=0;i<steps;++i)mm=nextMarker(mm,s_.navDir);bool pol=hallSupports(o,polarityAt(mm));s_.distanceConfirmed=interval.usable();
  if(steps>1){s_.missedSinceLast=uint8_t(steps-1);accept(mm,o,s_.missedSinceLast,EvidenceClass::MissedMarker);return Ruling::MissedAndAdvanced;}
  accept(mm,o,0,pol?EvidenceClass::Confirmed:EvidenceClass::PolarityDiscrepancy);return pol?Ruling::Advanced:Ruling::AdvancedWithDiscrepancy;
 }
private:
 static bool hallSupports(const NavObservation&o,uint8_t expected){return o.polarity==expected||(o.windowValid&&o.windowPolarity==expected);}
 uint8_t nearestForwardMarker(double traveled)const{double best=traveled;uint8_t bestStep=0;uint32_t cum=0;uint8_t cur=anchorMm_;for(uint8_t step=1;step<=MAX_UNCONFIRMED_MARKERS+1;++step){cum+=spanMm(cur,s_.navDir);cur=nextMarker(cur,s_.navDir);double e=traveled-double(cum);if(e<0)e=-e;if(e<best){best=e;bestStep=step;}}return bestStep;}
 void accept(uint8_t mm,const NavObservation&o,uint8_t missed,EvidenceClass why){s_.navMm=mm;s_.target=nextMarker(mm,s_.navDir);s_.state=NavState::Tracking;s_.trust=Trust::Continuity;s_.evidence=why;s_.unresolvedCount=0;s_.advances+=uint32_t(missed)+1;s_.sequenceLength=s_.sequenceLength<RECOVERY_WORD?uint8_t(s_.sequenceLength+1):RECOVERY_WORD;if(hallSupports(o,polarityAt(mm))){if(s_.sequenceMatches<RECOVERY_WORD)++s_.sequenceMatches;}else s_.sequenceMatches=0;pushPolarity(o.polarity);anchorMm_=mm;anchorMs_=o.openedAtMs;lastAcceptedMs_=o.openedAtMs;if(o.movement.issue==ngr_nav::MotionIssue::None){anchorMovement_=o.movement;haveAnchor_=true;}else haveAnchor_=false;refreshView();}
 void pushPolarity(uint8_t p){history_[historyHead_]=p?1:0;historyHead_=uint8_t((historyHead_+1)%RECOVERY_WORD);if(historyCount_<RECOVERY_WORD)++historyCount_;}
 bool uniqueHistoryMatch(uint8_t&endMm)const{if(historyCount_<RECOVERY_WORD||!s_.navDir)return false;uint8_t matches=0,matchEnd=0;for(uint16_t end=0;end<ROUTE_N;++end){bool ok=true;for(uint8_t k=0;k<RECOVERY_WORD;++k){uint8_t hi=uint8_t((historyHead_+k)%RECOVERY_WORD);int32_t off=int32_t(RECOVERY_WORD-1-k)*s_.navDir;uint8_t mapMm=routeMod(int32_t(end)-off);if(history_[hi]!=polarityAt(mapMm)){ok=false;break;}}if(ok){++matches;matchEnd=uint8_t(end);if(matches>1)return false;}}if(matches==1){endMm=matchEnd;return true;}return false;}
 void refreshView(){view_.set(consoleHasReference(s_.state),s_.navMm,s_.navDir,anchorMs_,anchorMovement_,s_.distanceConfirmed,s_.irIssue,s_.sequenceLength);}
 NavStatus s_{};PositionView view_{};bool reset_=false,haveAnchor_=false;uint8_t anchorMm_=0;uint32_t anchorMs_=0,lastAcceptedMs_=0;ngr_nav::MotionPoint anchorMovement_{};uint8_t history_[RECOVERY_WORD]{};uint8_t historyCount_=0,historyHead_=0;
};
} // namespace navi_one
