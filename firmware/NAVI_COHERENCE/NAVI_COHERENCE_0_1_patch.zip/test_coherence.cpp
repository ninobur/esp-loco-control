#include <cassert>
#include <iostream>
#include "Navigator.h"
using namespace navi_one;
static ngr_nav::MotionPoint mp(uint64_t pulses,uint64_t us){ngr_nav::MotionPoint p{};p.issue=ngr_nav::MotionIssue::None;p.frame=1;p.wire.bootId=1;p.wire.capturedUs=us;p.wire.completedPulses=pulses;p.wire.observedRises=pulses;p.wire.pitchUm=9652;p.wire.opticalReason=ir_movement::TRACKING;return p;}
int main(){
 Navigator n;n.declare(55,1);
 NavObservation a{};a.openedAtMs=1000;a.polarity=polarityAt(56);a.movement=mp(100,1000000);assert(n.judge(a)==Ruling::Advanced);assert(n.status().navMm==56);
 // Spurious lobe: only 5 pulses (~48 mm) after MM56, and only 200 ms later.
 NavObservation b{};b.openedAtMs=1200;b.polarity=polarityAt(57);b.movement=mp(105,1200000);assert(n.judge(b)==Ruling::NonLandmark);assert(n.status().navMm==56);
 // Real MM57 at mapped distance, polarity deliberately wrong: position still advances.
 uint64_t need=(spanMm(56,1)+5)/10; // approximate 9.652 mm pulses
 NavObservation c{};c.openedAtMs=2000;c.polarity=!polarityAt(57);c.movement=mp(100+need,2000000);auto rc=n.judge(c);assert(rc==Ruling::AdvancedWithDiscrepancy);assert(n.status().navMm==57);
 // Duplicate/field lobe while stopped over MM57: no movement, must not become MM58.
 NavObservation d{};d.openedAtMs=2700;d.polarity=polarityAt(58);d.movement=c.movement;d.movement.wire.capturedUs=2700000;assert(n.judge(d)==Ruling::NonLandmark);assert(n.status().navMm==57);
 std::cout<<"NAVI_COHERENCE focused checks passed\n";
}
