# NAVI_COHERENCE 0.1

A deliberately simple continuity-first navigator for Toby.

## Normal rule

NAVI already knows where Toby was and which mapped magnet comes next.

1. Operator declaration establishes position and direction.
2. The track map establishes the next expected MM.
3. IR wheel travel measures physical progress from the last accepted MM when usable.
4. Hall normally confirms arrival at the expected mapped landmark.
5. A Hall excursion before Toby has traveled far enough to reach a mapped magnet is `NON_LANDMARK_HALL` and does not move position or the IR anchor.
6. If measured travel is closest to a later mapped magnet, intermediate MMs are recorded as missed and NAVI continues from the physically coherent MM.
7. Wrong Hall polarity at the physically expected location is `POLARITY_DISCREPANCY`; NAVI advances and looks to the next landmark for further confirmation.
8. If IR is unavailable, NAVI continues from continuity + map + Hall with the existing 500 ms minimum-marker timing gate as fallback. Missing IR is not contradictory evidence.
9. While stopped over a magnet, no wheel travel means another Hall lobe cannot become the next MM.

There is one normal position. No branch/fault budget and no one-strike rule.

## Recovery

If more than ten mapped landmarks of physical progress pass without a coherent confirmation, NAVI changes to `UNCERTAIN`. It does not invent several locations. It collects a rolling ten-polarity Hall word; the route table states every ten-marker word is unique. A unique match restores one position and normal continuity.

This is a backstop, not the normal navigation loop.

## Evidence hierarchy

- Operator declaration: authoritative initialization.
- Route map/direction/history: physical continuity.
- IR: independent physical travel measurement and primary too-early gate when usable.
- Timing: fallback too-early gate (500 ms in this first build).
- Hall: landmark confirmation; polarity disagreement is diagnostic unless the broader physical model also fails.
- PWM: retained by the locomotive control system and telemetry, but not used as proof of physical movement in 0.1.

## Changed files

- `NAVI_COHERENCE.ino` — derived from NAVI_IR 0.2's proven Toby motor/MQTT/Hall/ESP-NOW scaffolding; version/telemetry and call sites updated for coherence rulings.
- `Navigator.h` — new single-position continuity engine. Does not include or use `HypothesisNavigator.h`.
- `RecoveryControl.h` — station controller adapter for the single current position.
- `test_coherence.cpp` — focused native regression for normal advance, early false Hall rejection, wrong-polarity-at-right-place advance, and repeated Hall activity while stopped.

## Verification performed here

The focused native test compiles with C++17, `-Wall -Wextra -Werror`, AddressSanitizer and UndefinedBehaviorSanitizer and passes.

A full ESP32/Arduino build was **not** possible in this isolated working directory because the complete repo/Arduino library environment is not present. Before flashing Toby, apply these files to the real repo and run the repo host suite plus both ESP32 builds. The old NAVI_IR branch-model tests will need replacement where they assert branch/fault behavior that NAVI_COHERENCE intentionally removes.

## First field test

Manual only. AUTO remains gated. The most important telemetry sequence is:

`DECLARED -> expected MM -> NON_LANDMARK_HALL for too-early lobes -> ADVANCED/ADVANCED_WITH_DISCREPANCY at the physically expected MM -> next expected MM`

Do not tune IR thresholds during the run. Preserve Pi IR and locomotive telemetry for post-run comparison.
