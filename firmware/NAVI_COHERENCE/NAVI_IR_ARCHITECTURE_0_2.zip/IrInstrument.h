#pragma once
#include <stdint.h>
#include "../../common/IrMovementWire.h"

namespace ngr_nav {

// Instrument condition and measurement readiness are deliberately separate.
//
// HEALTH answers: "Does the IR apparatus/data path appear to be functioning?"
// READY answers:  "Could wheel movement be observed continuously right now?"
//
// Neither answers whether the locomotive SHOULD be moving.
enum class IrHealthFault : uint8_t {
  None=0, NoSource, LinkStale, PacketInvalid, OrderFault,
  CalibrationFault, InadequateContrast, Saturation, SampleGap, PulseFault
};

enum class IrReadiness : uint8_t {
  Ready=0,
  Priming,
  Reacquiring,
  Unavailable
};

struct IrInstrumentState {
  bool healthy=false;
  IrHealthFault fault=IrHealthFault::NoSource;
  IrReadiness readiness=IrReadiness::Unavailable;
  ir_movement::Reason detectorReason=ir_movement::PRIMING;

  bool measurementReady() const {
    return healthy && readiness==IrReadiness::Ready;
  }
};

inline const char* irHealthFaultName(IrHealthFault r){
  switch(r){
    case IrHealthFault::None:return "NONE";
    case IrHealthFault::NoSource:return "NO_SOURCE";
    case IrHealthFault::LinkStale:return "LINK_STALE";
    case IrHealthFault::PacketInvalid:return "PACKET_INVALID";
    case IrHealthFault::OrderFault:return "ORDER_FAULT";
    case IrHealthFault::CalibrationFault:return "CALIBRATION_FAULT";
    case IrHealthFault::InadequateContrast:return "INADEQUATE_CONTRAST";
    case IrHealthFault::Saturation:return "SATURATION";
    case IrHealthFault::SampleGap:return "SAMPLE_GAP";
    case IrHealthFault::PulseFault:return "PULSE_FAULT";
    default:return "UNKNOWN";
  }
}

inline const char* irReadinessName(IrReadiness r){
  switch(r){
    case IrReadiness::Ready:return "READY";
    case IrReadiness::Priming:return "PRIMING";
    case IrReadiness::Reacquiring:return "REACQUIRING";
    default:return "UNAVAILABLE";
  }
}

// This classifies the instantaneous snapshot only. Transport freshness,
// monotonic ordering, and changes in cumulative fault counters are checked by
// IrOdometryStream, because they require comparison with prior snapshots.
//
// SIGNAL_STALE is intentionally interpreted as READY. In the legacy detector it
// means only "no completed pulse recently." Fresh packets + unchanged count are
// valid zero movement. It has no health or continuity authority here.
inline IrInstrumentState classifyIrInstrument(const ir_movement::WireSnapshot& w){
  IrInstrumentState s;
  s.detectorReason=w.opticalReason;

  if(!w.bootId || !w.pitchUm || !w.calibrationId){
    s.fault=IrHealthFault::CalibrationFault;
    return s;
  }

  switch(w.opticalReason){
    case ir_movement::INADEQUATE_CONTRAST:
      s.fault=IrHealthFault::InadequateContrast;
      return s;
    case ir_movement::SATURATION:
      s.fault=IrHealthFault::Saturation;
      return s;
    case ir_movement::SAMPLE_GAP:
      s.fault=IrHealthFault::SampleGap;
      return s;

    case ir_movement::PRIMING:
      s.healthy=true;
      s.fault=IrHealthFault::None;
      s.readiness=IrReadiness::Priming;
      return s;

    case ir_movement::REACQUIRING:
      s.healthy=true;
      s.fault=IrHealthFault::None;
      s.readiness=IrReadiness::Reacquiring;
      return s;

    case ir_movement::SIGNAL_STALE:
    case ir_movement::TRACKING:
      s.healthy=true;
      s.fault=IrHealthFault::None;
      s.readiness=IrReadiness::Ready;
      return s;

    default:
      s.fault=IrHealthFault::PacketInvalid;
      return s;
  }
}

} // namespace ngr_nav
