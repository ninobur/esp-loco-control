#pragma once
#include <stdint.h>
#include "../../common/IrMovementWire.h"
#include "IrInstrument.h"

namespace ngr_nav {

// Why the old distance chain can no longer be joined to the new one.
enum class IrContinuityBreak : uint8_t {
  None=0,
  FirstObservation,
  InstrumentUnavailable,
  NotReady,
  BootChanged,
  CalibrationChanged,
  PitchChanged,
  TimeOrder,
  CounterOrder,
  SampleGapOccurred,
  SaturationOccurred,
  PulseAbortOccurred,
  InferenceOccurred
};

inline const char* irContinuityBreakName(IrContinuityBreak r){
  switch(r){
    case IrContinuityBreak::None:return "NONE";
    case IrContinuityBreak::FirstObservation:return "FIRST_OBSERVATION";
    case IrContinuityBreak::InstrumentUnavailable:return "INSTRUMENT_UNAVAILABLE";
    case IrContinuityBreak::NotReady:return "NOT_READY";
    case IrContinuityBreak::BootChanged:return "BOOT_CHANGED";
    case IrContinuityBreak::CalibrationChanged:return "CALIBRATION_CHANGED";
    case IrContinuityBreak::PitchChanged:return "PITCH_CHANGED";
    case IrContinuityBreak::TimeOrder:return "TIME_ORDER";
    case IrContinuityBreak::CounterOrder:return "COUNTER_ORDER";
    case IrContinuityBreak::SampleGapOccurred:return "SAMPLE_GAP_OCCURRED";
    case IrContinuityBreak::SaturationOccurred:return "SATURATION_OCCURRED";
    case IrContinuityBreak::PulseAbortOccurred:return "PULSE_ABORT_OCCURRED";
    case IrContinuityBreak::InferenceOccurred:return "INFERENCE_OCCURRED";
    default:return "UNKNOWN";
  }
}

// One internally continuous run of odometry. A new run begins after startup or
// any event that could have hidden/corrupted wheel travel.
//
// Crucial distinction:
//   - a continuity break INVALIDATES an old MM reference;
//   - it does NOT permanently disable odometry.
// Once READY samples resume, a new run exists immediately and can measure
// movement/distance forward from its own origin.
class IrOdometryStream {
 public:
  struct Update {
    bool accepted=false;          // snapshot structurally accepted
    bool ready=false;             // movement measurable at this snapshot
    bool newRun=false;            // this snapshot starts a new odometry run
    bool continuityBroken=false;  // old MM reference must be invalidated
    IrContinuityBreak reason=IrContinuityBreak::None;
  };

  void reset(){
    have_=false; runValid_=false; runId_=0;
    bootId_=0; calibrationId_=0; pitchUm_=0;
    pulses_=runOriginPulses_=0; capturedUs_=0;
    sampleGaps_=saturated_=openAborts_=inferredAdded_=inferredRemoved_=0;
  }

  Update ingest(const ir_movement::WireSnapshot& w,
                const IrInstrumentState& instrument){
    Update u;

    if(!instrument.healthy){
      if(have_ || runValid_) {
        u.continuityBroken=true;
        u.reason=IrContinuityBreak::InstrumentUnavailable;
      }
      runValid_=false;
      rememberDiagnostics(w);
      return u;
    }

    // PRIMING/REACQUIRING return before normal pulse processing in the current
    // detector. The apparatus may be healthy, but movement can be missed.
    if(!instrument.measurementReady()){
      if(runValid_){
        u.continuityBroken=true;
        u.reason=IrContinuityBreak::NotReady;
      }
      runValid_=false;
      rememberDiagnostics(w);
      return u;
    }

    if(!have_){
      adopt(w);
      beginRun();
      u.accepted=u.ready=u.newRun=true;
      u.continuityBroken=false; // nothing older exists to invalidate here
      u.reason=IrContinuityBreak::FirstObservation;
      return u;
    }

    IrContinuityBreak br=IrContinuityBreak::None;
    if(w.bootId!=bootId_) br=IrContinuityBreak::BootChanged;
    else if(w.calibrationId!=calibrationId_) br=IrContinuityBreak::CalibrationChanged;
    else if(w.pitchUm!=pitchUm_) br=IrContinuityBreak::PitchChanged;
    else if(w.capturedUs<=capturedUs_) br=IrContinuityBreak::TimeOrder;
    else if(w.completedPulses<pulses_) br=IrContinuityBreak::CounterOrder;
    else if(w.sampleGaps>sampleGaps_) br=IrContinuityBreak::SampleGapOccurred;
    else if(w.saturatedSamples>saturated_) br=IrContinuityBreak::SaturationOccurred;
    else if(w.openAborts>openAborts_) br=IrContinuityBreak::PulseAbortOccurred;
    else if(w.inferredAdded>inferredAdded_ || w.inferredRemoved>inferredRemoved_)
      br=IrContinuityBreak::InferenceOccurred;

    if(br!=IrContinuityBreak::None){
      adopt(w);
      beginRun(); // recovered snapshot is a valid NEW origin
      u.accepted=u.ready=u.newRun=true;
      u.continuityBroken=true;
      u.reason=br;
      return u;
    }

    adopt(w);
    runValid_=true;
    u.accepted=u.ready=true;
    return u;
  }

  bool haveMeasurement() const {return have_;}
  bool runValid() const {return have_ && runValid_;}
  uint32_t runId() const {return runId_;}

  uint64_t pulses() const{return pulses_;}
  uint64_t capturedUs() const{return capturedUs_;}
  uint32_t pitchUm() const{return pitchUm_;}
  uint64_t bootId() const{return bootId_;}
  uint32_t calibrationId() const{return calibrationId_;}

  double runDistanceMm() const {
    if(!runValid_ || pulses_<runOriginPulses_) return 0.0;
    return double(pulses_-runOriginPulses_)*double(pitchUm_)/1000.0;
  }

 private:
  void beginRun(){
    ++runId_;
    runOriginPulses_=pulses_;
    runValid_=true;
  }

  void adopt(const ir_movement::WireSnapshot& w){
    have_=true;
    bootId_=w.bootId; calibrationId_=w.calibrationId; pitchUm_=w.pitchUm;
    pulses_=w.completedPulses; capturedUs_=w.capturedUs;
    rememberDiagnostics(w);
  }

  void rememberDiagnostics(const ir_movement::WireSnapshot& w){
    sampleGaps_=w.sampleGaps;
    saturated_=w.saturatedSamples;
    openAborts_=w.openAborts;
    inferredAdded_=w.inferredAdded;
    inferredRemoved_=w.inferredRemoved;
  }

  bool have_=false,runValid_=false;
  uint32_t runId_=0;
  uint64_t bootId_=0,capturedUs_=0,pulses_=0,runOriginPulses_=0;
  uint32_t calibrationId_=0,pitchUm_=0;
  uint64_t sampleGaps_=0,saturated_=0,openAborts_=0;
  uint64_t inferredAdded_=0,inferredRemoved_=0;
};

} // namespace ngr_nav
