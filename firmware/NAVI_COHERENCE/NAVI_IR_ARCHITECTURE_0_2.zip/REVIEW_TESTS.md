# Review cases for 0.2

These are architecture cases, not yet compiled host tests.

1. Startup, stationary
   Healthy packets arrive; detector PRIMING -> health healthy, readiness PRIMING.
   No odometry run until READY.
   First READY snapshot begins run 1. Zero pulse change thereafter is valid.

2. Normal stop
   READY/TRACKING -> READY/SIGNAL_STALE with fresh packets and unchanged counters.
   Same run ID. MM reference remains valid. Distance increment = 0.

3. Station dwell then depart
   No continuity break solely because no pulse completed for >2.5 s.
   New pulses continue same run and same MM reference.

4. Sample gap
   sampleGaps increments.
   Old run/reference invalid.
   First READY snapshot after the gap begins a new run.
   New movement is measurable immediately; old MM distance is not.

5. IR reboot
   bootId changes.
   New READY snapshot begins new run.
   Old MM reference invalid.
   Next independently accepted MM may establish a new reference.

6. Reacquiring
   Apparatus may be healthy, but detector returns before normal pulse processing.
   Readiness REACQUIRING; old run continuity is broken if movement could occur.
   First later READY snapshot begins new run.

7. Inadequate contrast
   Instrument unavailable. Old run invalid.
   Recovery to READY begins new run.

8. Counter unchanged while PWM > 0
   IR reports zero movement. IR does not diagnose.
   NAVI compares this with Hall/PWM/state.

9. Hall MM accepted on new run
   MmDistanceReference establishes against run ID and pulse count.
   +/-15% distance-from-MM may resume after this synchronization.
