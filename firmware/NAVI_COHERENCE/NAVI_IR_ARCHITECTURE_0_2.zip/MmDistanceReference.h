#pragma once
#include <stdint.h>
#include "IrOdometryStream.h"

namespace ngr_nav {

// IR says: "we have moved this much."
// NAVI + an accepted MM says: "this is where we are."
//
// This reference joins those facts. It is valid only within the exact odometry
// run on which it was established.
class MmDistanceReference {
 public:
  void invalidate(){valid_=false;}

  bool establish(uint8_t mm,uint32_t hallDetectedAtMs,
                 const IrOdometryStream& odo){
    if(!odo.runValid()){
      valid_=false;
      return false;
    }
    valid_=true;
    mm_=mm;
    hallDetectedAtMs_=hallDetectedAtMs;
    irCapturedUs_=odo.capturedUs();
    pulseCount_=odo.pulses();
    pitchUm_=odo.pitchUm();
    bootId_=odo.bootId();
    calibrationId_=odo.calibrationId();
    runId_=odo.runId();
    return true;
  }

  bool validFor(const IrOdometryStream& odo) const {
    return valid_ && odo.runValid() &&
           odo.runId()==runId_ &&
           odo.bootId()==bootId_ &&
           odo.calibrationId()==calibrationId_ &&
           odo.pitchUm()==pitchUm_ &&
           odo.pulses()>=pulseCount_;
  }

  double distanceFromMm(const IrOdometryStream& odo) const {
    if(!validFor(odo)) return 0.0;
    return double(odo.pulses()-pulseCount_)*double(pitchUm_)/1000.0;
  }

  bool valid() const{return valid_;}
  uint8_t mm() const{return mm_;}
  uint32_t hallDetectedAtMs() const{return hallDetectedAtMs_;}
  uint64_t irCapturedUs() const{return irCapturedUs_;}
  uint64_t pulseCount() const{return pulseCount_;}
  uint32_t runId() const{return runId_;}

 private:
  bool valid_=false;
  uint8_t mm_=0;
  uint32_t hallDetectedAtMs_=0,runId_=0;
  uint64_t irCapturedUs_=0,pulseCount_=0,bootId_=0;
  uint32_t pitchUm_=0,calibrationId_=0;
};

} // namespace ngr_nav
