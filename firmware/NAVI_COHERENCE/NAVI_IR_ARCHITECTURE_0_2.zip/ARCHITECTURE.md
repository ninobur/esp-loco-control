# NAVI IR Architecture 0.2
Date: 2026-09-23
Status: architecture review package; not wired into NAVI_COHERENCE

This is a clean rewrite of 0.1, not a patch.

## Four separate facts

1. Instrument health
   Is the IR apparatus/data path functioning?

2. Measurement readiness
   Could wheel movement actually be observed at this moment?
   PRIMING and REACQUIRING are healthy-but-not-ready because the current
   detector returns before normal pulse processing in those states.

3. Odometry run
   IR measures "we have moved this much." A true blind interval ends one run.
   When READY data returns, a NEW run begins immediately. The new run is valid
   forward from its own origin; it cannot reconstruct the missing distance.

4. MM distance reference
   NAVI associates a valid MM detection with the current IR count/run:
       MM identity + Hall timestamp + IR count + run ID
   This turns odometry into "distance from MMxxx."
   A reference cannot cross an odometry-run boundary.

## Zero movement

Fresh packets with unchanged completedPulses are valid zero movement.
The legacy SIGNAL_STALE reason has no health or continuity authority.
True packet staleness belongs to the communications layer.

## Cumulative integrity counters

A change in these counters breaks the old odometry run:
- sampleGaps
- saturatedSamples
- openAborts
- inferredAdded / inferredRemoved

`unreliableSamples` is deliberately NOT used because the current sender
increments it for every detector state other than TRACKING, including legitimate
zero/stationary conditions. Its semantics carry the old agent model.

## Discontinuity behavior

On a real discontinuity:
- old MM reference becomes invalid;
- recovered READY snapshot starts a new valid odometry run immediately;
- movement/distance/speed can be measured forward from that new origin;
- a later independently accepted MM establishes a new MM distance reference.

This fixes 0.1's permanent-continuity bug.

## Not implemented here

- packet-arrival freshness (belongs around MovementSource transport)
- NAVI actions
- telemetry
- 70-count Hall detector
- 650-ms Hall-only guard
- +/-15% landmark gate
- stations/AUTO
- position correction

No firmware source has been modified.
