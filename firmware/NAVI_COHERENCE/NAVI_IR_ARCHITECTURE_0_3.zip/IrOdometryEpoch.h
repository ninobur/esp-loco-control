#pragma once
#include <stdint.h>
#include "../../common/IrMovementWire.h"
#include "IrInstrument.h"
namespace ngr_nav {
enum class IrEpochBreak:uint8_t{None=0,FirstObservation,InstrumentUnavailable,NotReady,BootChanged,CalibrationChanged,PitchChanged,TimeOrder,CounterOrder,SampleGapOccurred,SaturationOccurred,PulseAbortOccurred,InferenceOccurred};
class IrOdometryEpoch{
public:
 struct Update{bool snapshotAccepted=false,measurementReady=false,epochStarted=false,epochEnded=false;uint32_t epochId=0;IrEpochBreak reason=IrEpochBreak::None;};
 void reset(){haveSnapshot_=false;epochActive_=false;haveEverEpoch_=false;epochId_=0;bootId_=capturedUs_=pulses_=epochOriginPulses_=0;calibrationId_=pitchUm_=0;sampleGaps_=saturated_=openAborts_=inferredAdded_=inferredRemoved_=0;}
 Update ingest(const ir_movement::WireSnapshot&w,const IrInstrumentState&i){
  Update u;u.epochId=epochId_;
  if(!i.healthy||!i.measurementReady()){if(epochActive_){epochActive_=false;u.epochEnded=true;u.reason=!i.healthy?IrEpochBreak::InstrumentUnavailable:IrEpochBreak::NotReady;}rememberDiagnostics(w);return u;}
  if(!haveSnapshot_||!epochActive_){adopt(w);beginEpoch();u.snapshotAccepted=u.measurementReady=u.epochStarted=true;u.epochId=epochId_;u.reason=haveEverEpoch_?IrEpochBreak::None:IrEpochBreak::FirstObservation;haveEverEpoch_=true;return u;}
  IrEpochBreak b=IrEpochBreak::None;
  if(w.bootId!=bootId_)b=IrEpochBreak::BootChanged;else if(w.calibrationId!=calibrationId_)b=IrEpochBreak::CalibrationChanged;else if(w.pitchUm!=pitchUm_)b=IrEpochBreak::PitchChanged;else if(w.capturedUs<=capturedUs_)b=IrEpochBreak::TimeOrder;else if(w.completedPulses<pulses_)b=IrEpochBreak::CounterOrder;else if(w.sampleGaps>sampleGaps_)b=IrEpochBreak::SampleGapOccurred;else if(w.saturatedSamples>saturated_)b=IrEpochBreak::SaturationOccurred;else if(w.openAborts>openAborts_)b=IrEpochBreak::PulseAbortOccurred;else if(w.inferredAdded>inferredAdded_||w.inferredRemoved>inferredRemoved_)b=IrEpochBreak::InferenceOccurred;
  if(b!=IrEpochBreak::None){u.epochEnded=true;adopt(w);beginEpoch();u.snapshotAccepted=u.measurementReady=u.epochStarted=true;u.epochId=epochId_;u.reason=b;haveEverEpoch_=true;return u;}
  adopt(w);u.snapshotAccepted=u.measurementReady=true;u.epochId=epochId_;return u;}
 bool epochActive()const{return epochActive_;}uint32_t epochId()const{return epochId_;}bool haveMeasurement()const{return haveSnapshot_&&epochActive_;}uint64_t pulses()const{return pulses_;}uint64_t capturedUs()const{return capturedUs_;}uint32_t pitchUm()const{return pitchUm_;}uint64_t bootId()const{return bootId_;}uint32_t calibrationId()const{return calibrationId_;}
 double epochDistanceMm()const{return(!epochActive_||pulses_<epochOriginPulses_)?0.0:double(pulses_-epochOriginPulses_)*double(pitchUm_)/1000.0;}
private:
 void beginEpoch(){++epochId_;epochOriginPulses_=pulses_;epochActive_=true;}
 void adopt(const ir_movement::WireSnapshot&w){haveSnapshot_=true;bootId_=w.bootId;calibrationId_=w.calibrationId;pitchUm_=w.pitchUm;pulses_=w.completedPulses;capturedUs_=w.capturedUs;rememberDiagnostics(w);}
 void rememberDiagnostics(const ir_movement::WireSnapshot&w){sampleGaps_=w.sampleGaps;saturated_=w.saturatedSamples;openAborts_=w.openAborts;inferredAdded_=w.inferredAdded;inferredRemoved_=w.inferredRemoved;}
 bool haveSnapshot_=false,epochActive_=false,haveEverEpoch_=false;uint32_t epochId_=0;uint64_t bootId_=0,capturedUs_=0,pulses_=0,epochOriginPulses_=0;uint32_t calibrationId_=0,pitchUm_=0;uint64_t sampleGaps_=0,saturated_=0,openAborts_=0,inferredAdded_=0,inferredRemoved_=0;
};}