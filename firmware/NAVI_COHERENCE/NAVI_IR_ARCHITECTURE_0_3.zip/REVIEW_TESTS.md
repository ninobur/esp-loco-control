# Required review cases
1. Startup PRIMING: healthy/not-ready/no epoch. First READY -> Epoch 1.
2. Fresh packets + unchanged count >2.5 s: same epoch, zero movement.
3. Contrast outage: active epoch ends once; first later READY starts next epoch; old MM reference fails by epoch ID.
4. REACQUIRING ends active epoch; later READY starts next epoch.
5. Hidden sampleGap increment between READY snapshots ends old epoch and starts new one on second snapshot.
6. bootId change starts new epoch and invalidates old reference by epoch ID.
7. Independently accepted MM synchronizes new epoch.
8. No pulse change is not communications loss; no fresh packets must be handled by transport as unavailable and end epoch.
9. Without calling reference.invalidate(), old reference must fail validFor() after every epoch transition.
