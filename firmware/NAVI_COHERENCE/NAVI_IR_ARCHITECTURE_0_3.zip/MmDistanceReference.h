#pragma once
#include <stdint.h>
#include "IrOdometryEpoch.h"
namespace ngr_nav {
class MmDistanceReference{
public:
 void invalidate(){valid_=false;}
 bool synchronize(uint8_t mm,uint32_t hallMs,const IrOdometryEpoch&o){if(!o.haveMeasurement()){valid_=false;return false;}valid_=true;mm_=mm;hallMs_=hallMs;pulse_=o.pulses();pitch_=o.pitchUm();boot_=o.bootId();cal_=o.calibrationId();epoch_=o.epochId();return true;}
 bool validFor(const IrOdometryEpoch&o)const{return valid_&&o.haveMeasurement()&&o.epochId()==epoch_&&o.bootId()==boot_&&o.calibrationId()==cal_&&o.pitchUm()==pitch_&&o.pulses()>=pulse_;}
 double distanceFromMm(const IrOdometryEpoch&o)const{return validFor(o)?double(o.pulses()-pulse_)*double(pitch_)/1000.0:0.0;}
 uint32_t epochId()const{return epoch_;}
private:bool valid_=false;uint8_t mm_=0;uint32_t hallMs_=0,epoch_=0;uint64_t pulse_=0,boot_=0;uint32_t pitch_=0,cal_=0;
};}