# NAVI IR Architecture 0.3
Date: 2026-09-23
Status: proposed architecture for review; not wired into NAVI_COHERENCE

## IR Epoch
An **IR Epoch** is an uninterrupted interval of valid IR odometry during which IR can account for all wheel movement continuously.

A normal stop, zero movement, or station dwell does not end an IR Epoch. Anything capable of allowing wheel movement to occur without reliable measurement ends it. **An ended epoch never reopens.** The first later measurement-ready snapshot begins a new epoch.

## Four independent facts
1. Instrument health — is the apparatus/data path functioning?
2. Measurement readiness — can movement actually be observed now?
3. IR Epoch/odometry — "we have moved this much."
4. MM synchronization/reference — "this odometry is referenced to MMxxx."

## Recovery invariant
Unavailable/not-ready ends the active epoch once. READY recovery always begins a new epoch. Old MM references become unusable automatically because they carry the old epoch ID. Correctness does not depend on outside code calling invalidate().

## Hidden discontinuities
While snapshots appear READY, increases in sampleGaps, saturatedSamples, openAborts, inferredAdded or inferredRemoved end the current epoch and the same READY snapshot becomes the origin of a new epoch. `unreliableSamples` is excluded because its current semantics include legitimate non-TRACKING stationary states.

## SIGNAL_STALE
Legacy SIGNAL_STALE has no architectural authority. Fresh packets plus unchanged pulse count are valid zero movement. True stale data means packets stopped arriving.

## PRIMING / REACQUIRING
The current detector returns before normal pulse processing in these states. The apparatus may be healthy but measurement is not ready. Either state ends an active epoch because movement could go uncounted.

No NAVI_COHERENCE firmware is modified by this package.
