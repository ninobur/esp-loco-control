#pragma once
#include <stdint.h>
#include "../../common/IrMovementWire.h"
namespace ngr_nav {
enum class IrHealthFault:uint8_t{None=0,NoSource,LinkStale,PacketInvalid,OrderFault,CalibrationFault,InadequateContrast,Saturation,SampleGap,PulseFault};
enum class IrReadiness:uint8_t{Ready=0,Priming,Reacquiring,Unavailable};
struct IrInstrumentState{bool healthy=false;IrHealthFault fault=IrHealthFault::NoSource;IrReadiness readiness=IrReadiness::Unavailable;ir_movement::Reason detectorReason=ir_movement::PRIMING;bool measurementReady()const{return healthy&&readiness==IrReadiness::Ready;}};
inline IrInstrumentState classifyIrInstrument(const ir_movement::WireSnapshot&w){
 IrInstrumentState s;s.detectorReason=w.opticalReason;
 if(!w.bootId||!w.pitchUm||!w.calibrationId){s.fault=IrHealthFault::CalibrationFault;return s;}
 switch(w.opticalReason){
 case ir_movement::INADEQUATE_CONTRAST:s.fault=IrHealthFault::InadequateContrast;return s;
 case ir_movement::SATURATION:s.fault=IrHealthFault::Saturation;return s;
 case ir_movement::SAMPLE_GAP:s.fault=IrHealthFault::SampleGap;return s;
 case ir_movement::PRIMING:s.healthy=true;s.fault=IrHealthFault::None;s.readiness=IrReadiness::Priming;return s;
 case ir_movement::REACQUIRING:s.healthy=true;s.fault=IrHealthFault::None;s.readiness=IrReadiness::Reacquiring;return s;
 case ir_movement::SIGNAL_STALE:
 case ir_movement::TRACKING:s.healthy=true;s.fault=IrHealthFault::None;s.readiness=IrReadiness::Ready;return s;
 default:s.fault=IrHealthFault::PacketInvalid;return s;}}
}